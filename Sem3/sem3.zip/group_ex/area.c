#include "SP.h"

int area(int a, int b) {
    return a * b;
}