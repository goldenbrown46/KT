#include <stdio.h>
#include <math.h>

int peri(int a, int b);

int area(int a, int b);